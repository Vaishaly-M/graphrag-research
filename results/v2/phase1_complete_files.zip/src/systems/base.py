from __future__ import annotations

import argparse
import json
import time
from pathlib import Path
from typing import Any

import pandas as pd

from src.common import (
    ROOT,
    append_jsonl,
    completed_ids,
    read_jsonl,
    write_jsonl,
)


DEFAULT_PILOT_BENCHMARK = Path(
    "data/benchmark/benchmark_pilot_7.csv"
)

DEFAULT_PILOT_OUTPUT_DIR = Path(
    "results/v2/default"
)


STRUCTURED_COLUMNS = {
    "retrieved_evidence",
    "predicted_relations",
    "predicted_path",
    "generated_cypher",
    "retrieval_errors",
    "adaptive_plan",
    "graph_results",
    "vector_results",
    "routing_metadata",
}


def add_run_arguments(
    parser: argparse.ArgumentParser,
) -> None:
    """Add shared command-line arguments for every system."""

    parser.add_argument(
        "--benchmark-file",
        type=Path,
        default=DEFAULT_PILOT_BENCHMARK,
        help=(
            "Benchmark file to execute. "
            "Both CSV and JSONL are supported."
        ),
    )

    parser.add_argument(
        "--output-dir",
        type=Path,
        default=DEFAULT_PILOT_OUTPUT_DIR,
        help="Directory in which result files will be written.",
    )

    parser.add_argument(
        "--limit",
        type=int,
        default=None,
        help="Optional maximum number of benchmark questions.",
    )

    parser.add_argument(
        "--reset",
        action="store_true",
        help="Delete existing result files before execution.",
    )

    parser.add_argument(
        "--repeats",
        type=int,
        default=1,
        help=(
            "Run each question this many times (Guide Section 15.2), "
            "e.g. to measure variance under nondeterministic generation. "
            "Each repeat is tagged with run_id and a composite run_key so "
            "resumption never confuses one repeat for another."
        ),
    )


class BaseSystem:
    """Shared benchmark runner used by all QA systems."""

    name = "base"

    def answer(
        self,
        question: str,
    ) -> str | dict[str, Any]:
        raise NotImplementedError

    @staticmethod
    def _resolve_path(
        path: str | Path,
    ) -> Path:
        resolved = Path(path)

        if resolved.is_absolute():
            return resolved

        return ROOT / resolved

    @staticmethod
    def _normalise_result(
        result: str | dict[str, Any],
    ) -> dict[str, Any]:
        """
        Convert an answer into a standard result dictionary.
        """
        if isinstance(result, dict):
            normalised = dict(result)
            normalised.setdefault("answer", "")
            return normalised

        return {
            "answer": str(result),
        }

    @staticmethod
    def _load_benchmark(
        benchmark_path: Path,
    ) -> list[dict[str, Any]]:
        """
        Load a benchmark from CSV or JSONL.
        """
        suffix = benchmark_path.suffix.lower()

        if suffix == ".jsonl":
            rows = read_jsonl(benchmark_path)

        elif suffix == ".csv":
            dataframe = pd.read_csv(
                benchmark_path,
                encoding="utf-8",
            )

            # Replace pandas NaN values with None so JSON output is valid.
            dataframe = dataframe.where(
                pd.notna(dataframe),
                None,
            )

            rows = dataframe.to_dict(
                orient="records",
            )

        else:
            raise ValueError(
                "Unsupported benchmark format: "
                f"{benchmark_path.suffix}. "
                "Use a .csv or .jsonl benchmark file."
            )

        BaseSystem._validate_benchmark_rows(
            rows,
            benchmark_path,
        )

        return rows

    @staticmethod
    def _validate_benchmark_rows(
        rows: list[dict[str, Any]],
        benchmark_path: Path,
    ) -> None:
        """
        Confirm that the benchmark contains the required columns.
        """
        if not rows:
            raise ValueError(
                f"Benchmark file contains no questions: "
                f"{benchmark_path}"
            )

        for index, row in enumerate(rows, start=1):
            if "question" not in row:
                raise ValueError(
                    f"Benchmark row {index} has no "
                    f"'question' field."
                )

            if row.get("question") is None:
                raise ValueError(
                    f"Benchmark row {index} has an empty "
                    f"'question' field."
                )

            # Accept either id or question_id.
            if (
                row.get("id") is None
                and row.get("question_id") is None
            ):
                # Frozen evaluations require source IDs, never row-order identifiers.
                raise ValueError(f"Benchmark row {index} has no question ID")

    @staticmethod
    def _serialise_csv_value(
        value: Any,
    ) -> Any:
        """
        Convert nested structures into valid JSON strings for CSV output.
        """
        if isinstance(
            value,
            (
                dict,
                list,
                tuple,
                set,
            ),
        ):
            return json.dumps(
                value,
                ensure_ascii=False,
                default=str,
            )

        return value

    @classmethod
    def _export_csv(
        cls,
        jsonl_path: Path,
        csv_path: Path,
    ) -> None:
        """
        Export result JSONL rows to a CSV file.
        """
        rows = read_jsonl(jsonl_path)

        if not rows:
            print(
                f"No rows available for CSV export: "
                f"{jsonl_path}"
            )
            return

        csv_rows: list[dict[str, Any]] = []

        for row in rows:
            csv_row: dict[str, Any] = {}

            for key, value in row.items():
                if (
                    key in STRUCTURED_COLUMNS
                    or isinstance(
                        value,
                        (
                            dict,
                            list,
                            tuple,
                            set,
                        ),
                    )
                ):
                    csv_row[key] = cls._serialise_csv_value(
                        value
                    )
                else:
                    csv_row[key] = value

            csv_rows.append(csv_row)

        dataframe = pd.DataFrame(csv_rows)

        dataframe.to_csv(
            csv_path,
            index=False,
            encoding="utf-8-sig",
        )

    def run(self, benchmark=DEFAULT_PILOT_BENCHMARK, output_dir=DEFAULT_PILOT_OUTPUT_DIR,
            limit=None, reset=False, repeats=1, discard_first_run=False, no_cache=False):
        from src.evaluation.harness_v2 import run
        return run(self, benchmark, output_dir, limit=limit, reset=reset, repeats=repeats,
                   discard_first_run=discard_first_run, no_cache=no_cache)
